let searchForm = document.querySelector('.search_form');
document.querySelector('#search_btn').onclick = () => {
    searchForm.classList.toggle('active');
    navBar.classList.remove('active');
}

let navBar = document.querySelector('.navbar');
document.querySelector('#menu_btn').onclick = () => {
    navBar.classList.toggle('active');
}
// for filter button script
let filterBtn = document.querySelectorAll('.filter_buttons .buttons');
let filterItem = document.querySelectorAll('.exclusive_collection .box_container .box');

filterBtn.forEach(button =>  {
  button.onclick = () =>{
    filterBtn.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');

    let dataFilter = button.getAttribute('data-filter');

    filterItem.forEach(item => {
      item.classList.remove('active');
      item.classList.add('hide');

      if(item.getAttribute('data-item') == dataFilter || dataFilter == 'all'){
        item.classList.remove('hide');
        item.classList.add('active');
      }
    });
  };
});
window.onscroll = () => {
  searchForm.classList.remove('active');
  navBar.classList.remove('active');
};
//for pagination script 

var swiper = new Swiper(".home_slider", {
    centeredSlides: true,
    loop:true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
    pagination: {
      el: ".swiper-pagination",
      type: "progressbar",
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });


var swiper = new Swiper(".category_slider", {
  centeredSlides: true,
  loop:true,
  spaceBetween:20,
  autoplay: {
      delay: 2500,
      disableOnInteraction: false,
    },
  pagination: {
    el: ".swiper-pagination",
    type: "progressbar",
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  breakpoints:
  {
    0:
    {
      slidesPerView: 1,
    },
    450:
    {
      slidesPerView: 2,
    },
    768:
    {
      slidesPerView: 3,
    },
    1200:
    {
      slidesPerView: 4
    }
  }
});


