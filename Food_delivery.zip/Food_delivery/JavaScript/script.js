// for searchbar script
let searchForm = document.querySelector('.search_form_container');

document.querySelector('#search_btn').onclick = () => {
    searchForm.classList.toggle('active');
    wishlist.classList.remove('active');
    user_section.classList.remove('active');
    navbar.classList.remove('active'); 
}
    // for cart script
    let wishlist = document.querySelector('.wishlist_container');

    document.querySelector('#cart_btn').onclick = () => {
        wishlist.classList.toggle('active');
        searchForm.classList.remove('active');
        user_section.classList.remove('active');
        navbar.classList.remove('active');   
}
    //  for user script
let user_section = document.querySelector('.user_form_container');

document.querySelector('#login_btn').onclick = () => {
    user_section.classList.toggle('active');
    searchForm.classList.remove('active');
    wishlist.classList.remove('active');
    navbar.classList.remove('active'); 
} 
    // for humburger script
    let navbar = document.querySelector('.header .navbar');
    document.querySelector('#menu_btn').onclick = () => {
        navbar.classList.toggle('active');
        searchForm.classList.remove('active');
        wishlist.classList.remove('active');
        user_section.classList.remove('active'); 
}

window.onscroll = () =>{
    navbar.classList.remove('active');
}