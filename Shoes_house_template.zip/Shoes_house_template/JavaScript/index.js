let menu = document.querySelector('#hum_burger');
let navbar = document.querySelector('.navBar');

menu.onclick = () =>{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}
window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}

// Sliding Image

let slides = document.querySelectorAll('.slide_container');
let index = 0;

function next(){
    slides[index].classList.remove('active');
    index = (index + 1) % slides.length;
    slides[index].classList.add('active');
}

function prev(){
    slides[index].classList.remove('active');
    index = (index - 1 + slides.length ) % slides.length;
    slides[index].classList.add('active');
}

var swiper = new Swiper(".review_slider", {
    spaceBetween:20,
    pagination: {
      el: ".swiper-pagination",
      clickable : true,
    },
    autoplay:{
        delay:7500,
        disableOnInteraction:false
    },
        breakpoints: {
      0: {
        slidesPerView: 2,
      },
      768: {
        slidesPerView: 2,
      },
    },
    loop : true,
    grabCursor : true
  });

  const scrollHeader = () => {
    const header = document.getElementById('navBar');
    this.scrollY >= 50 ? header.classList.add('scroll-header')
                    : header.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)